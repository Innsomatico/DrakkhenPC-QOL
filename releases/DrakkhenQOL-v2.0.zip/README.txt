Drakkhen QOL patch (US GOG and Steam releases)
==============================================

Mods included:
  * Compass in the 3D view (needle tracks your heading)
  * World map on the M key, with your position flashing
  * Quest hints on the H key (SPACE reveals the next hint - spoilers are your choice)
  * Spell/phial runes replaced with readable English letters
  * Rings/sceptres/phials show WHICH one they are next to the type name
  * Rings and sceptres now WORK: wearing one grants its effect (Invisibility,
    Protection, Recuperation = double regen, Acceleration, Power, Understanding,
    Impalpability). The stock game shipped these effects unwired.
  * Class-based stat growth on level-up (the stock game grants none at all)
  * Kill XP shared: every living party member gets 1/4 of each award
  * Bow buffed from weakest weapon in the game to a real choice (power 8, on par with
    the short sword), renamed from "arch"
  * New characters start with their gear already EQUIPPED (the stock game hands it
    over unworn, so a fresh party walks out unarmed until you equip 14 items by hand)
  * The scout starts with a bow instead of a dagger
  * Tavern rumors are free (stock escalates 50 -> 4000 jade per hint, saved
    per-party, silently pricing you out of information forever)
  * A merchant shop in every zone: the stock game ships a full working shop
    (sell, buy-back, loyalty discounts) placed in ONE building on the whole
    island - now each zone's spare hut is a merchant, including one near the
    Earth-zone start
  * The magician starts wearing a RESTORE ring (double regen, via the ring mod)
  * Copy-protection code prompt removed; video-card menu skipped (always VGA)
  * Optional cleanup: unused CGA/EGA/Tandy files (~1.5 MB) moved into the backup
    folder (they are unreachable once the video card is pinned to VGA)

Install:
  1. Copy install.ps1 into your Drakkhen folder:
       GOG   - the folder holding DRAKKHEN.COM and DRAKM.CC1, typically
               C:\Program Files\GOG Galaxy\Games\Drakkhen
       Steam - the folder ABOVE game\, typically
               C:\Program Files (x86)\Steam\steamapps\common\Drakkhen
               (the installer locates game\ by itself and says so)
  2. Right-click install.ps1 -> Run with PowerShell
     (or from a terminal:  powershell -ExecutionPolicy Bypass -File install.ps1)

The installer verifies your files are the stock US GOG version before touching
anything, backs them up to _backup\original\, rebuilds the patched files from
YOUR OWN game data, and verifies the result byte-for-byte. If any check fails
it stops without changing your game.

Uninstall:
  powershell -ExecutionPolicy Bypass -File install.ps1 -Restore

Save files are never touched by install or restore.

Optional: use a modern DOSBox
-----------------------------
GOG and Steam both ship DOSBox 0.74 (2010). DOSBox Staging is a maintained fork
with sharper output, CRT/HD shaders, far better AdLib music emulation, and
modern fullscreen handling. This patch does NOT include it - download the
portable zip yourself from https://dosbox-staging.github.io/ , then run:

  python staging_setup.py <your game folder> <your unpacked Staging folder>

That points your existing GOG/Steam Play button at Staging (originals backed up;
undo with  staging_setup.py <game folder> --restore ).
